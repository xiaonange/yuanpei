<?php

return array(
    'view_filter' => array('Library\Behavior\EmptyImageBehavior'),
);
