<?php

/**
 * 默认数据库配置
 * 
 * @author anyon <cxphp@qq.com>
 * @date 2014/08/02 15:33:22
 * @return array Config
 */
return array(
    'DB_TYPE'   => 'mysql', //数据库默认连接方式
    'DB_HOST'   => '45.78.44.182', //数据库服务器默认地址
    'DB_NAME'   => 'yuanpeishop', //数据库默认名称
    'DB_USER'   => 'root', //数据库默认用户名
    'DB_PWD'    => 'admin7758258', //数据库默认密码
    'DB_PORT'   => '3306', //数据库默认连接端口
    'DB_PREFIX' => 'wx_', //数据表默认前缀
);
