<?php

/**
 * 默认数据库配置
 * 
 * @author anyon <cxphp@qq.com>
 * @date 2014/08/02 15:33:22
 * @return array Config
 */
return array(
    'DB_TYPE'   => 'mysql', //数据库默认连接方式
    'DB_HOST'   => '{DB_ADDRESS}', //数据库服务器默认地址
    'DB_NAME'   => '{DB_NAME}', //数据库默认名称
    'DB_USER'   => '{DB_USER}', //数据库默认用户名
    'DB_PWD'    => '{DB_PASS}', //数据库默认密码
    'DB_PORT'   => '{DB_PORT}', //数据库默认连接端口
    'DB_PREFIX' => '{TABLE_PREFIX}', //数据表默认前缀
);
