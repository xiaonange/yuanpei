-- Create syntax for TABLE 'think_cache'
CREATE TABLE `think_cache` (
  `cachekey` varchar(255) NOT NULL,
  `expire` int(11) NOT NULL,
  `data` blob,
  `datacrc` char(32) DEFAULT NULL,
  UNIQUE KEY `cachekey` (`cachekey`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Create syntax for TABLE 'think_session'
CREATE TABLE `think_session` (
  `session_id` varchar(255) NOT NULL,
  `session_expire` int(11) NOT NULL,
  `session_data` blob,
  UNIQUE KEY `session_id` (`session_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Create syntax for TABLE '{pre}app'
CREATE TABLE `{pre}app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '应用名称',
  `host` varchar(50) DEFAULT NULL COMMENT '应用主机地址',
  `auth` char(32) NOT NULL DEFAULT '' COMMENT '应用认证码',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '2' COMMENT '状态 2:启用 1:禁止',
  `remark` varchar(255) DEFAULT '' COMMENT '备注说明',
  `qiniu_accesskey` varchar(128) DEFAULT NULL COMMENT '七牛AK',
  `qiniu_secretkey` varchar(128) DEFAULT NULL COMMENT '七牛SK',
  `qiniu_bucket` varchar(128) DEFAULT NULL COMMENT '七牛Bucket',
  `qiniu_domain` varchar(128) DEFAULT NULL COMMENT '七牛域名',
  `qiniu_rename` tinyint(11) DEFAULT '0' COMMENT '七牛重全名，1 开启重命名，0 保留原名称',
  `get_number` int(11) DEFAULT '0' COMMENT '授权次数',
  `get_last_date` datetime DEFAULT NULL COMMENT '最后授权时间',
  `get_last_ip` varchar(15) DEFAULT NULL COMMENT '最后授权IP',
  `get_last_domain` varchar(128) DEFAULT NULL COMMENT '最授权域名',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `username` (`host`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统用户表';

-- Create syntax for TABLE '{pre}apps_eggs'
CREATE TABLE `{pre}apps_eggs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startpicurl` varchar(255) NOT NULL COMMENT '填写活动开始图片网址',
  `title` varchar(255) NOT NULL COMMENT '活动名称',
  `info` varchar(255) NOT NULL COMMENT '活动说明',
  `endinfo` varchar(255) NOT NULL COMMENT '活动结束回复',
  `canrqnums` int(22) NOT NULL COMMENT '个人限制抽奖次数',
  `status` int(1) NOT NULL COMMENT '活动状态,2进行中,1已关闭',
  `first` int(11) unsigned NOT NULL COMMENT '一等奖奖品设置',
  `first_rate` decimal(4,2) unsigned DEFAULT NULL COMMENT '一等奖机率',
  `second` int(11) unsigned NOT NULL COMMENT '二等奖奖品设置',
  `second_rate` decimal(4,2) unsigned DEFAULT NULL COMMENT '二等机率',
  `third` int(11) unsigned NOT NULL COMMENT '三等奖',
  `third_rate` decimal(4,2) unsigned DEFAULT NULL COMMENT '三等机率',
  `four` int(11) unsigned NOT NULL COMMENT '四等奖奖品设置',
  `four_rate` decimal(4,2) unsigned DEFAULT NULL COMMENT '四等奖机率',
  `five` int(11) unsigned NOT NULL COMMENT '五等奖',
  `five_rate` decimal(4,2) unsigned DEFAULT NULL COMMENT '五等奖机率',
  `six` int(11) unsigned NOT NULL COMMENT '六等奖奖品设置',
  `six_rate` decimal(4,2) unsigned DEFAULT NULL COMMENT '六等奖机率',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='砸金蛋活动主表';

-- Create syntax for TABLE '{pre}apps_eggs_record'
CREATE TABLE `{pre}apps_eggs_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) NOT NULL DEFAULT '' COMMENT '会员openid',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '奖项名称',
  `prize` varchar(60) NOT NULL DEFAULT '' COMMENT '已中奖项',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='砸金蛋活动记录表';

-- Create syntax for TABLE '{pre}apps_lottery'
CREATE TABLE `{pre}apps_lottery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keys` varchar(30) DEFAULT NULL COMMENT '关键字',
  `link` varchar(200) DEFAULT NULL COMMENT '活动图片',
  `joinnum` int(11) NOT NULL COMMENT '参与人数',
  `aginfo` int(11) NOT NULL COMMENT '重复抽奖次数',
  `title` varchar(60) NOT NULL COMMENT '活动名称',
  `content` varchar(200) NOT NULL COMMENT '活动说明',
  `first` varchar(50) NOT NULL COMMENT '一等奖奖品设置',
  `firstnums` int(4) NOT NULL COMMENT '一等奖奖品数量',
  `firstlucknums` int(1) NOT NULL COMMENT '一等奖中奖号码',
  `second` varchar(50) NOT NULL COMMENT '二等奖奖品设置',
  `type` tinyint(1) NOT NULL,
  `secondnums` int(4) NOT NULL,
  `secondlucknums` int(1) NOT NULL,
  `third` varchar(50) NOT NULL,
  `thirdnums` int(4) NOT NULL,
  `thirdlucknums` int(1) NOT NULL,
  `allpeople` int(11) NOT NULL,
  `canrqnums` int(2) NOT NULL COMMENT '个人限制抽奖次数',
  `displayjpnums` int(1) NOT NULL,
  `four` varchar(50) NOT NULL,
  `fournums` int(11) NOT NULL,
  `fourlucknums` int(11) NOT NULL,
  `five` varchar(50) NOT NULL,
  `fivenums` int(11) NOT NULL,
  `fivelucknums` int(11) NOT NULL,
  `six` varchar(50) NOT NULL COMMENT '六等奖',
  `sixnums` int(11) NOT NULL,
  `sixlucknums` int(11) NOT NULL,
  `kouchujifen` int(10) DEFAULT '0' COMMENT '抽奖一次扣除多少积分',
  `status` int(4) unsigned DEFAULT NULL COMMENT '1 禁止 2 启用 3 进行时 4 结束',
  `startdate` date DEFAULT NULL COMMENT '开始时间',
  `enddate` date DEFAULT NULL COMMENT '结束时间',
  `create_by` int(11) DEFAULT NULL COMMENT '创建人',
  `update_by` int(11) DEFAULT NULL COMMENT '更新人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `endinfo` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='大转盘活动主表';

-- Create syntax for TABLE '{pre}apps_lottery_record'
CREATE TABLE `{pre}apps_lottery_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `awards` tinyint(1) NOT NULL COMMENT '奖项：一等奖->1',
  `prize` varchar(50) NOT NULL DEFAULT '' COMMENT '已中奖项',
  `openid` varchar(30) NOT NULL,
  `usenums` tinyint(2) NOT NULL DEFAULT '0' COMMENT '用户使用次数',
  `type` tinyint(2) NOT NULL DEFAULT '0',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `status` tinyint(1) NOT NULL COMMENT '得奖状态，1不中2中',
  `sncode` varchar(20) DEFAULT NULL COMMENT '兑换码',
  `accept_name` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `province` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `area` varchar(30) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `postcode` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COMMENT='大转盘活动记录表';

-- Create syntax for TABLE '{pre}apps_puzzle'
CREATE TABLE `{pre}apps_puzzle` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `update_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `update_by` int(11) DEFAULT NULL COMMENT '所属门店id',
  `link` varchar(500) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `times` int(11) DEFAULT '0' COMMENT '第天参与次数',
  `integral` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='拼图游戏主表';

-- Create syntax for TABLE '{pre}apps_puzzle_record'
CREATE TABLE `{pre}apps_puzzle_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(64) NOT NULL,
  `ctime` int(11) NOT NULL,
  `time` char(8) DEFAULT NULL COMMENT '用时：秒',
  `step` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`openid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='拼图游戏记录表';

-- Create syntax for TABLE '{pre}apps_survey'
CREATE TABLE `{pre}apps_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) DEFAULT NULL COMMENT '问卷名称',
  `status` int(1) NOT NULL COMMENT '问题状态',
  `count` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '参与次数',
  `integral` int(11) unsigned DEFAULT NULL COMMENT '奖励积分',
  `update_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `update_by` int(11) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='问卷调查主表';

-- Create syntax for TABLE '{pre}apps_survey_problem'
CREATE TABLE `{pre}apps_survey_problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) DEFAULT NULL COMMENT '问题名称',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '问题创建时间',
  `status` int(1) NOT NULL COMMENT '问题状态',
  `check_type` int(1) NOT NULL DEFAULT '0' COMMENT '单多选模式，0单选，1多选',
  `answer_a` varchar(1000) DEFAULT NULL COMMENT '答案A',
  `number_a` int(11) DEFAULT '0' COMMENT '答案A的选择人数',
  `answer_b` varchar(1000) DEFAULT NULL,
  `number_b` int(11) DEFAULT '0',
  `answer_c` varchar(1000) DEFAULT NULL,
  `number_c` int(11) DEFAULT '0',
  `answer_d` varchar(1000) DEFAULT NULL,
  `number_d` int(11) DEFAULT '0',
  `answer_e` varchar(1000) DEFAULT NULL,
  `number_e` int(11) DEFAULT '0',
  `answer_f` varchar(1000) DEFAULT NULL,
  `number_f` int(11) DEFAULT '0',
  `update_date` datetime DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  `create_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='问卷调查问题表';

-- Create syntax for TABLE '{pre}apps_survey_record'
CREATE TABLE `{pre}apps_survey_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='问卷调查记录';

-- Create syntax for TABLE '{pre}apps_vote'
CREATE TABLE `{pre}apps_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `data_json` longtext,
  `pdcount` tinyint(10) DEFAULT '0' COMMENT '数量',
  `sort` varchar(30) NOT NULL,
  `status` int(11) NOT NULL,
  `integral` int(11) DEFAULT NULL COMMENT '点赞送积分值',
  `praise_per_day` tinyint(4) DEFAULT NULL COMMENT '每天允许点赞数',
  `create_by` int(11) DEFAULT NULL,
  `create_date` datetime NOT NULL,
  `update_date` datetime DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='照片评比主表';

-- Create syntax for TABLE '{pre}apps_vote_item'
CREATE TABLE `{pre}apps_vote_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `sort` varchar(30) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0' COMMENT '投票数',
  `status` int(11) NOT NULL,
  `vote_id` int(11) NOT NULL,
  `openid` varchar(64) DEFAULT NULL,
  `check` int(11) DEFAULT '1' COMMENT '审核状态：1、未审核 2、已审核',
  `create_by` int(11) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` int(11) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='照片评比内容表';

-- Create syntax for TABLE '{pre}apps_vote_record'
CREATE TABLE `{pre}apps_vote_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL,
  `pid` int(30) NOT NULL COMMENT '投票项ID',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `openid` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='照片评比记录表';

-- Create syntax for TABLE '{pre}baby_daily'
CREATE TABLE `{pre}baby_daily` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `openid` varchar(50) DEFAULT NULL COMMENT 'openid',
  `content` text,
  `images` text,
  `sids` text COMMENT '资源ID',
  `click` bigint(20) DEFAULT '0' COMMENT '访问次数',
  `open` int(11) DEFAULT '0' COMMENT '是否公开 1公开，0 不公开',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='宝宝日志主表';

-- Create syntax for TABLE '{pre}baby_daily_praise'
CREATE TABLE `{pre}baby_daily_praise` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint(20) DEFAULT NULL COMMENT '记录ID',
  `openid` varchar(50) DEFAULT NULL COMMENT '用户openid',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '点赞时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COMMENT='宝宝日志点赞表';

-- Create syntax for TABLE '{pre}member'
CREATE TABLE `{pre}member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(100) DEFAULT NULL COMMENT '用户openid',
  `name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `qq` varchar(32) DEFAULT NULL COMMENT 'qq号码',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号码',
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `postal` varchar(20) DEFAULT NULL COMMENT '邮政编码',
  `age` date DEFAULT NULL COMMENT '用户生日',
  `status` tinyint(1) DEFAULT '2' COMMENT '用户状态 2已关注 1已取消关注',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `integral` int(11) DEFAULT '0' COMMENT '可用积分',
  `total_integral` int(11) DEFAULT '0' COMMENT '总积分',
  `used_integral` int(11) DEFAULT '0' COMMENT '消费积分',
  PRIMARY KEY (`id`),
  KEY `member_openid_index` (`openid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='业务用户表';

-- Create syntax for TABLE '{pre}member_address'
CREATE TABLE `{pre}member_address` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `is_default` int(11) DEFAULT '1' COMMENT '是否为默认地址 1 不是 2 是',
  `openid` varchar(64) NOT NULL COMMENT '会员openid',
  `accept_name` varchar(20) DEFAULT '' COMMENT '收货人姓名',
  `postcode` varchar(6) DEFAULT '' COMMENT '邮编',
  `phone` varchar(20) DEFAULT '' COMMENT '联系电话',
  `mail` varchar(50) DEFAULT '' COMMENT '电子邮箱',
  `country` varchar(20) DEFAULT '中国' COMMENT '国家',
  `province` varchar(20) DEFAULT '' COMMENT '省份',
  `city` varchar(20) DEFAULT '' COMMENT '城市',
  `area` varchar(20) DEFAULT '' COMMENT '区域',
  `address` varchar(250) DEFAULT '' COMMENT '详细地址',
  `status` tinyint(4) DEFAULT '2' COMMENT '状态，1、禁用，2、启用，3、默认记录',
  `type` varchar(20) DEFAULT '手动填写' COMMENT '地址来源类型',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '数据创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户收货地址表';

-- Create syntax for TABLE '{pre}member_integral'
CREATE TABLE `{pre}member_integral` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(100) DEFAULT NULL COMMENT '用户openid',
  `desc` varchar(200) DEFAULT NULL COMMENT '变动的描述信息',
  `integral` bigint(11) DEFAULT '0' COMMENT '积分变动，加/减',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `member_integral_openid_index` (`openid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='用户积分记录表';

-- Create syntax for TABLE '{pre}site_config'
CREATE TABLE `{pre}site_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(100) DEFAULT NULL COMMENT '官网标题',
  `is_wechat_auth` int(11) DEFAULT '1' COMMENT '默认微信认证授权 1关闭，2开启',
  `is_disable` tinyint(2) DEFAULT '1' COMMENT '1 关闭 2 开启',
  `disabled_msg` text COMMENT '网站关闭后的提示消息',
  `page_share_integral` int(11) DEFAULT '1' COMMENT '页面分享积分',
  `content_share_integral` int(11) DEFAULT '1' COMMENT '内容分享积分',
  `baidu_tongji_key` varchar(50) DEFAULT NULL COMMENT '百度统计Key',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='前端网站配置表';

-- Create syntax for TABLE '{pre}site_content'
CREATE TABLE `{pre}site_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `is_show_title` int(11) DEFAULT '2' COMMENT '是否显示标题 1 不显示 2 显示',
  `title` varchar(200) DEFAULT NULL COMMENT '文章标题',
  `is_wechat_auth` int(11) DEFAULT '1' COMMENT '微信网页认证 1 关闭 2 开启',
  `cid` int(11) DEFAULT NULL COMMENT '文章分类ID',
  `keys` varchar(200) DEFAULT NULL COMMENT '文章关键字，以#,#隔开',
  `is_show_link` int(11) DEFAULT '1' COMMENT '是否显示Top图片 1不显示 2显示',
  `link` varchar(200) DEFAULT NULL COMMENT '图片',
  `integral` int(11) DEFAULT '0' COMMENT '分享获取积分',
  `content` text COMMENT '文章内容',
  `url` varchar(200) DEFAULT NULL COMMENT '跳转链接',
  `is_show` int(11) DEFAULT '2' COMMENT '是否前台显示 1 不显示 2显示',
  `click` bigint(20) DEFAULT '0' COMMENT '阅读次数',
  `status` tinyint(4) DEFAULT '2' COMMENT '文章状态',
  `sort` bigint(20) DEFAULT NULL COMMENT '排序',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='前端内容表';

-- Create syntax for TABLE '{pre}site_content_cat'
CREATE TABLE `{pre}site_content_cat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '0' COMMENT '类型ID',
  `title` varchar(100) DEFAULT NULL COMMENT '分类标题',
  `link` varchar(200) DEFAULT NULL COMMENT '图片',
  `desc` varchar(500) DEFAULT NULL COMMENT '描述',
  `is_show` int(11) DEFAULT '2' COMMENT '前台显示  1 不显示 2 显示',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态 2启用 1禁用',
  `sort` bigint(20) DEFAULT '0' COMMENT '排序',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='前端内容分类表';

-- Create syntax for TABLE '{pre}site_page'
CREATE TABLE `{pre}site_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `is_wechat_auth` int(11) DEFAULT '1' COMMENT '微信网页认证 1 关闭 2 开启',
  `title` varchar(200) DEFAULT NULL COMMENT '数据标题',
  `is_show_title` int(11) DEFAULT '1' COMMENT '显示top标题',
  `integral` int(11) DEFAULT '0' COMMENT '分享获取积分',
  `code` varchar(50) DEFAULT NULL COMMENT '内容代码',
  `keys` varchar(200) DEFAULT NULL COMMENT '微信关键字',
  `is_show_link` int(11) DEFAULT '1' COMMENT '显示top图版 2 显示',
  `link` varchar(200) DEFAULT '' COMMENT '图片地址',
  `module_ids` varchar(200) DEFAULT NULL COMMENT '模块IDs',
  `content` blob COMMENT 'JSON内容',
  `click` bigint(20) DEFAULT '0' COMMENT '点击数',
  `desc` varchar(400) DEFAULT NULL COMMENT '描述信息',
  `url` varchar(200) DEFAULT NULL COMMENT '跳转链接',
  `status` tinyint(4) DEFAULT '2' COMMENT '数据状态',
  `sort` bigint(20) DEFAULT NULL COMMENT '排序',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_data_code_index` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='前端页面表';

-- Create syntax for TABLE '{pre}site_page_module'
CREATE TABLE `{pre}site_page_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) DEFAULT NULL COMMENT '模块类型',
  `name` varchar(200) DEFAULT NULL COMMENT '数据标题',
  `keys` varchar(200) DEFAULT NULL COMMENT '微信关键字',
  `link` varchar(200) DEFAULT NULL COMMENT '图片链接',
  `content` blob COMMENT '模块内容',
  `desc` varchar(400) DEFAULT NULL COMMENT '描述信息',
  `url` varchar(200) DEFAULT NULL COMMENT '跳转链接',
  `status` tinyint(4) DEFAULT '2' COMMENT '数据状态',
  `sort` bigint(20) DEFAULT NULL COMMENT '排序',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='前端页面模块表';

-- Create syntax for TABLE '{pre}site_share_record'
CREATE TABLE `{pre}site_share_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `table` varchar(100) DEFAULT NULL COMMENT '分享内容',
  `table_id` bigint(20) DEFAULT NULL COMMENT '内容ID',
  `openid` varchar(64) DEFAULT '' COMMENT '分享者OPENID',
  `integral` int(11) DEFAULT '0' COMMENT '获得积分',
  `title` varchar(200) DEFAULT '1' COMMENT '分享的标题',
  `img` varchar(200) DEFAULT '' COMMENT '分享的图片',
  `type` varchar(20) DEFAULT NULL COMMENT '分享类型',
  `desc` varchar(300) DEFAULT '' COMMENT '分享的描述',
  `link` varchar(200) DEFAULT NULL COMMENT '分享链接',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='前端分享记录表';

-- Create syntax for TABLE '{pre}store'
CREATE TABLE `{pre}store` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '商店表 ID',
  `name` varchar(100) DEFAULT NULL COMMENT '商城名称',
  `phone` varchar(15) DEFAULT NULL COMMENT '联系电话',
  `{pre}pay` tinyint(4) DEFAULT '1' COMMENT '微信支付状态',
  `is_credit` tinyint(4) DEFAULT NULL COMMENT '1 关闭 2 禁止',
  `credit` int(11) DEFAULT NULL COMMENT '推荐者积分奖励分值',
  `be_credit` int(11) DEFAULT NULL COMMENT '被推荐者奖励分值',
  `is_discount` tinyint(2) DEFAULT '1' COMMENT '1 关闭 2 开启',
  `link` varchar(2048) DEFAULT NULL COMMENT 'top图片',
  `is_show_link` int(5) DEFAULT '1' COMMENT '是否显示top图片',
  `status` tinyint(4) DEFAULT '2' COMMENT '店铺状态',
  `desc` varchar(500) DEFAULT NULL COMMENT '店铺描述信息',
  `province` varchar(20) DEFAULT NULL COMMENT '地址#省份名称',
  `city` varchar(50) DEFAULT NULL COMMENT '地址#城市名称',
  `area` varchar(50) DEFAULT NULL COMMENT '地址#地区名称',
  `address` varchar(100) DEFAULT NULL COMMENT '地址#详细地址',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='店铺配置表';

-- Create syntax for TABLE '{pre}store_credit'
CREATE TABLE `{pre}store_credit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `credit_no` varchar(32) DEFAULT NULL,
  `openid` varchar(64) DEFAULT NULL COMMENT '会员OPENID',
  `product_id` int(11) DEFAULT NULL COMMENT '产品ID',
  `product_params` varchar(200) DEFAULT NULL COMMENT '产品信息',
  `num` int(11) DEFAULT NULL,
  `pay_type` tinyint(11) DEFAULT '0' COMMENT '支付方式  0：货到付款   1：微信支付',
  `freight_type` tinyint(11) DEFAULT '1' COMMENT '1、快递配送',
  `freight` varchar(50) DEFAULT NULL COMMENT '货运公司名',
  `freight_num` varchar(100) DEFAULT NULL COMMENT '物流单号',
  `pay_status` tinyint(11) DEFAULT '0' COMMENT '支付状态 0：未支付，1：已支付，2：已退款',
  `credit` int(11) DEFAULT NULL COMMENT '商品兑换所需积分',
  `total_credit` int(11) DEFAULT NULL COMMENT '兑换总积分',
  `get_method` int(2) DEFAULT NULL COMMENT '收货方式 1 自提 2 快递',
  `get_delivery` datetime DEFAULT NULL COMMENT '收货时间',
  `accept_name` varchar(100) DEFAULT NULL COMMENT '收件人',
  `postcode` int(11) DEFAULT NULL COMMENT '邮政编码',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `country` varchar(20) DEFAULT NULL COMMENT '国家',
  `province` varchar(20) DEFAULT NULL COMMENT '省份',
  `city` varchar(30) DEFAULT NULL COMMENT '城市',
  `area` varchar(30) DEFAULT NULL COMMENT '地区',
  `address` varchar(100) DEFAULT NULL COMMENT '详细地址',
  `post_script` varchar(500) DEFAULT NULL COMMENT '客户留言',
  `pay_freight` decimal(18,2) DEFAULT '0.00' COMMENT '总运费金额',
  `promotions` decimal(18,2) DEFAULT '0.00' COMMENT '促销优惠金额',
  `order_amount` decimal(18,2) DEFAULT '0.00' COMMENT '订单总金额',
  `status` tinyint(4) DEFAULT '1' COMMENT '订单状态 1新订单,2确认订单,3取消订单,4退货订单,5完成订单',
  `send_status` tinyint(4) DEFAULT '0' COMMENT '0 未发货 1 已发货 2 已签收',
  `freight_date` datetime DEFAULT NULL COMMENT '物流发货时间',
  `cancel_date` datetime DEFAULT NULL COMMENT '订单取消时间',
  `success_date` datetime DEFAULT NULL COMMENT '订单完成时间',
  `sign_date` datetime DEFAULT NULL COMMENT '签收货物时间',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='店铺积分订单表';

-- Create syntax for TABLE '{pre}store_credit_product'
CREATE TABLE `{pre}store_credit_product` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '积分商品表 ID',
  `code` varchar(32) DEFAULT NULL COMMENT '产品编号',
  `cat_id` bigint(20) DEFAULT NULL COMMENT '分类ID',
  `extend_cat` varchar(30) DEFAULT NULL COMMENT '扩展分类ID',
  `name` varchar(50) NOT NULL COMMENT '商品名称',
  `shortname` varchar(50) DEFAULT NULL COMMENT '产品简称',
  `product_sn` varchar(30) DEFAULT NULL COMMENT '货号',
  `barcode` varchar(30) DEFAULT NULL COMMENT '商品条码',
  `sell_credit` int(11) DEFAULT '0' COMMENT '兑换积分',
  `market_credit` int(11) DEFAULT '0' COMMENT '原积分',
  `up_date` datetime DEFAULT NULL COMMENT '上架时间',
  `down_date` datetime DEFAULT NULL COMMENT '下架时间',
  `store_nums` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `model_id` bigint(11) unsigned NOT NULL COMMENT '模型ID',
  `model_params` text COMMENT '模型参数 JSON',
  `params` text COMMENT '产品详细参数 JSON',
  `img` mediumblob COMMENT '展示图片',
  `logo` varchar(255) DEFAULT NULL COMMENT 'logo图片',
  `content` text COMMENT '商品描述',
  `property` text COMMENT '产品属性',
  `must_know` text COMMENT '兑换须知',
  `notice` text COMMENT '注意事项',
  `keywords` varchar(255) DEFAULT NULL COMMENT 'SEO关键词',
  `description` longtext COMMENT 'SEO描述',
  `search_words` text COMMENT '产品搜索词库,逗号分隔',
  `weight` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `unit` varchar(10) DEFAULT NULL COMMENT '计量单位',
  `visit` int(11) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `favorite` int(11) NOT NULL DEFAULT '0' COMMENT '收藏次数',
  `sort` smallint(5) NOT NULL DEFAULT '99' COMMENT '排序',
  `spec_array` text COMMENT '序列化存储规格,key值为规则ID，value为此商品具有的规格值',
  `exp` int(11) NOT NULL DEFAULT '0' COMMENT '经验值',
  `comments` int(11) NOT NULL DEFAULT '0' COMMENT '评论次数',
  `sale` int(11) NOT NULL DEFAULT '0' COMMENT '销量',
  `grade` int(11) NOT NULL DEFAULT '0' COMMENT '评分总数',
  `status` tinyint(11) DEFAULT '2' COMMENT '1 禁用 2 启用',
  `times_limit` int(4) DEFAULT '-1' COMMENT '-1：不限制，n：限制n次，0：暂不出售',
  `free_express` int(4) DEFAULT '0' COMMENT '0 不免邮 1 免邮',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='积分商品信息表';

-- Create syntax for TABLE '{pre}store_delivery'
CREATE TABLE `{pre}store_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '快递表 ID',
  `name` varchar(50) DEFAULT NULL COMMENT '快递名称',
  `description` varchar(50) DEFAULT NULL COMMENT '快递描述',
  `area_groupid` text COMMENT '配送区域id',
  `firstprice` text COMMENT '配送地址对应的首重价格',
  `secondprice` text COMMENT '配送地区对应的续重价格',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '配送类型 0先付款后发货 1先发货后付款',
  `first_weight` int(11) unsigned NOT NULL COMMENT '首重重量(克)',
  `second_weight` int(11) unsigned NOT NULL COMMENT '续重重量(克)',
  `first_price` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '首重价格',
  `second_price` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '续重价格',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '开启状态',
  `sort` smallint(5) NOT NULL DEFAULT '99' COMMENT '排序',
  `is_save_price` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否支持物流保价 1支持保价 0  不支持保价',
  `save_rate` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '保价费率',
  `low_price` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '最低保价',
  `price_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '费用类型 0统一设置 1指定地区费用',
  `open_default` tinyint(1) NOT NULL DEFAULT '1' COMMENT '启用默认费用 1启用 0 不启用',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='配送方式表';

-- Create syntax for TABLE '{pre}store_freight_company'
CREATE TABLE `{pre}store_freight_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `api_id` bigint(20) DEFAULT NULL COMMENT '接口应用ID',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '货运类型',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '货运公司名称',
  `url` varchar(255) NOT NULL COMMENT '网址',
  `sort` smallint(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '状态 1禁用 2启用',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新人',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='货运公司';

-- Create syntax for TABLE '{pre}store_notify'
CREATE TABLE `{pre}store_notify` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `OpenId` varchar(50) DEFAULT NULL COMMENT '用户openid',
  `IsSubscribe` tinyint(2) DEFAULT NULL COMMENT '是否关注，1为关注，0为未关注',
  `TimeStamp` varchar(20) DEFAULT NULL COMMENT '时间戳',
  `NonceStr` varchar(20) DEFAULT NULL COMMENT '随机串',
  `AppSignature` varchar(50) DEFAULT NULL COMMENT '加密签名',
  `bank_billno` varchar(50) DEFAULT NULL COMMENT '银行订单号',
  `bank_type` int(10) DEFAULT NULL COMMENT '银行类型',
  `discount` tinyint(2) DEFAULT NULL,
  `fee_type` tinyint(2) DEFAULT NULL COMMENT '币种，1人民币',
  `notify_id` varchar(100) DEFAULT NULL COMMENT '通知ID',
  `out_trade_no` varchar(50) DEFAULT NULL COMMENT '商户订单号',
  `partner` tinyint(10) DEFAULT NULL COMMENT '财付通身份标识',
  `product_fee` varchar(11) DEFAULT NULL COMMENT '产品费用',
  `sign` int(20) DEFAULT NULL COMMENT '签名',
  `time_end` varchar(20) DEFAULT NULL COMMENT '支付完成时间',
  `sign_type` varchar(20) DEFAULT NULL,
  `total_fee` varchar(11) DEFAULT NULL COMMENT '总金额，单位为分',
  `trade_mode` tinyint(2) DEFAULT NULL COMMENT '交易模式，1即时到帐',
  `trade_state` tinyint(2) DEFAULT NULL COMMENT '交易状态，0成功',
  `transaction_id` varchar(64) DEFAULT NULL COMMENT '订单号',
  `transport_fee` tinyint(2) DEFAULT NULL COMMENT '物流费用，默认0',
  `add_time` timestamp NULL DEFAULT NULL,
  `is_refund` varchar(10) DEFAULT NULL,
  `rmb_total_fee` varchar(10) DEFAULT NULL,
  `input_charset` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='支付日志表';

-- Create syntax for TABLE '{pre}store_order'
CREATE TABLE `{pre}store_order` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单表 ID',
  `order_no` varchar(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `openid` varchar(64) NOT NULL COMMENT '用户openid',
  `pay_type` int(11) NOT NULL DEFAULT '0' COMMENT '支付方式  0：货到付款   1：微信支付',
  `freight` varchar(50) DEFAULT NULL COMMENT '货运公司名',
  `freight_num` varchar(100) DEFAULT NULL COMMENT '物流单号',
  `status` tinyint(1) DEFAULT '1' COMMENT '订单状态 1新订单,2确认订单,3取消订单,4退款订单,5完成订单',
  `pay_status` tinyint(1) DEFAULT '0' COMMENT '支付状态 0：未支付，1：已支付，2：已退款',
  `send_status` tinyint(1) DEFAULT '0' COMMENT '配送状态 0：未发送,1：已发送,2：已经签收',
  `freight_date` datetime DEFAULT NULL COMMENT '物流发货时间',
  `cancel_date` datetime DEFAULT NULL COMMENT '订单取消时间',
  `success_date` datetime DEFAULT NULL COMMENT '订单完成时间',
  `sign_date` datetime DEFAULT NULL COMMENT '签收货物时间',
  `accept_name` varchar(20) NOT NULL COMMENT '收货人姓名',
  `postcode` varchar(6) DEFAULT NULL COMMENT '邮编',
  `phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `country` varchar(20) DEFAULT '中国' COMMENT '国家',
  `province` varchar(20) DEFAULT NULL COMMENT '省份',
  `city` varchar(20) DEFAULT NULL COMMENT '城市',
  `area` varchar(20) DEFAULT NULL COMMENT '区域',
  `address` varchar(250) DEFAULT NULL COMMENT '收货地址',
  `pay_amount` decimal(15,2) DEFAULT '0.00' COMMENT '应付商品总金额',
  `real_amount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '实付商品总金额',
  `pay_freight` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '总运费金额',
  `real_freight` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '实付运费',
  `pay_date` datetime DEFAULT NULL COMMENT '付款时间',
  `send_date` datetime DEFAULT NULL COMMENT '发货时间',
  `completion_date` datetime DEFAULT NULL COMMENT '订单完成时间',
  `invoice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发票：0不索要1索要',
  `post_script` varchar(255) DEFAULT NULL COMMENT '用户附言',
  `insured` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '保价',
  `if_insured` tinyint(1) DEFAULT '0' COMMENT '是否保价0:不保价，1保价',
  `pay_fee` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '支付手续费',
  `invoice_title` varchar(100) DEFAULT NULL COMMENT '发票抬头',
  `taxes` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '税金',
  `promotions` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '促销优惠金额',
  `discount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '订单折扣或涨价',
  `order_amount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '订单总金额',
  `print_type` varchar(255) DEFAULT NULL COMMENT '已打印的类型,类型的代码以逗号进行分割; shop购物单,pick配货单,merge购物和配货,express快递单',
  `prop` varchar(255) DEFAULT NULL COMMENT '使用的道具id',
  `accept_date` varchar(80) DEFAULT NULL COMMENT '用户收货时间',
  `exp` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '增加的经验',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '增加的积分',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0普通订单,1团购订单,2限时抢购',
  `trade_no` varchar(255) DEFAULT NULL COMMENT '支付平台交易号',
  `sync_code` varchar(30) DEFAULT NULL COMMENT '订单同步反馈代码',
  `sync_msg` varchar(100) DEFAULT NULL COMMENT '订单同步反馈信息',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下单时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COMMENT='商品订单表';

-- Create syntax for TABLE '{pre}store_order_car'
CREATE TABLE `{pre}store_order_car` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '购物车表 ID',
  `cid` bigint(20) NOT NULL COMMENT '商品ID',
  `openid` varchar(64) NOT NULL COMMENT '用户openid',
  `param` varchar(500) DEFAULT NULL COMMENT '产品参数',
  `num` bigint(20) DEFAULT '0' COMMENT '产品数量',
  `price` decimal(15,2) DEFAULT '0.00' COMMENT '单价,  仅供参考',
  `content` text COMMENT '购物内容',
  `status` int(11) DEFAULT '1' COMMENT '状态 1、新添加 2 已经完成',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COMMENT='用户购物车';

-- Create syntax for TABLE '{pre}store_order_product'
CREATE TABLE `{pre}store_order_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单商品表 ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `product_id` bigint(20) unsigned DEFAULT NULL COMMENT '产品ID',
  `openid` varchar(64) DEFAULT NULL COMMENT '会员openid',
  `product_name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `product_price` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `real_price` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '实付金额',
  `product_nums` int(11) NOT NULL DEFAULT '1' COMMENT '商品数量',
  `product_params` mediumtext COMMENT '产品属性参数',
  `params` varchar(255) DEFAULT NULL COMMENT '商品和货品名称name和规格value串json数据格式',
  `weight` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `img` varchar(255) NOT NULL COMMENT '商品图片',
  `salesman` int(11) DEFAULT NULL COMMENT '推销员',
  `sales_type` tinyint(4) DEFAULT NULL COMMENT '推销员类型',
  `split_price` decimal(15,2) DEFAULT '0.00' COMMENT '分成基数',
  `is_pay` tinyint(1) DEFAULT '0' COMMENT '0 未支付 1已支付',
  `is_send` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已发货 0:未发货;1:已发货',
  `is_checkout` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否给商家结算货款 0:未结算;1:已结算',
  `delivery_id` int(11) NOT NULL DEFAULT '0' COMMENT '配送ID',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='订单详细商品表';

-- Create syntax for TABLE '{pre}store_product'
CREATE TABLE `{pre}store_product` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品表 ID',
  `code` varchar(32) DEFAULT NULL COMMENT '产品编号',
  `cat_id` bigint(20) DEFAULT NULL COMMENT '分类ID',
  `extend_cat` varchar(30) DEFAULT NULL COMMENT '扩展分类ID',
  `name` varchar(50) NOT NULL COMMENT '商品名称',
  `shortname` varchar(50) DEFAULT NULL COMMENT '产品简称',
  `product_sn` varchar(30) DEFAULT NULL COMMENT '货号',
  `barcode` varchar(30) DEFAULT NULL COMMENT '商品条码',
  `sell_price` decimal(15,2) DEFAULT '0.00' COMMENT '销售价',
  `market_price` decimal(15,2) DEFAULT '0.00' COMMENT '市场价',
  `up_date` datetime DEFAULT NULL COMMENT '上架时间',
  `down_date` datetime DEFAULT NULL COMMENT '下架时间',
  `store_nums` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `model_id` bigint(11) unsigned NOT NULL COMMENT '模型ID',
  `model_params` text COMMENT '模型参数 JSON',
  `params` text COMMENT '产品详细参数 JSON',
  `img` mediumblob COMMENT '展示图片',
  `logo` varchar(255) DEFAULT NULL COMMENT 'logo图片',
  `content` text COMMENT '商品描述',
  `property` text COMMENT '产品属性',
  `must_know` text COMMENT '购买须知',
  `notice` text COMMENT '注意事项',
  `keywords` varchar(255) DEFAULT NULL COMMENT 'SEO关键词',
  `description` longtext COMMENT 'SEO描述',
  `search_words` text COMMENT '产品搜索词库,逗号分隔',
  `weight` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `point` int(11) NOT NULL DEFAULT '0' COMMENT '积分 0 禁止 1 启用',
  `unit` varchar(10) DEFAULT NULL COMMENT '计量单位',
  `visit` int(11) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `favorite` int(11) NOT NULL DEFAULT '0' COMMENT '收藏次数',
  `sort` smallint(5) NOT NULL DEFAULT '99' COMMENT '排序',
  `spec_array` text COMMENT '序列化存储规格,key值为规则ID，value为此商品具有的规格值',
  `exp` int(11) NOT NULL DEFAULT '0' COMMENT '经验值',
  `comments` int(11) NOT NULL DEFAULT '0' COMMENT '评论次数',
  `sale` int(11) NOT NULL DEFAULT '0' COMMENT '销量',
  `grade` int(11) NOT NULL DEFAULT '0' COMMENT '评分总数',
  `status` tinyint(11) DEFAULT '2' COMMENT '1 禁用 2 启用',
  `is_recommend` tinyint(2) DEFAULT '0' COMMENT '0 不推荐 1 推荐',
  `times_limit` int(4) DEFAULT '-1' COMMENT '-1：不限制，n：限制n次，0：暂不出售',
  `free_express` int(4) DEFAULT '0' COMMENT '0 不免邮 1 免邮',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COMMENT='商品信息表';

-- Create syntax for TABLE '{pre}store_product_cat'
CREATE TABLE `{pre}store_product_cat` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品分类表 ID',
  `pid` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '父分类ID',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `img` varchar(200) DEFAULT NULL COMMENT '图片',
  `sort` smallint(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '1 禁用 2启用',
  `model_id` int(11) unsigned NOT NULL COMMENT '默认模型ID',
  `keywords` varchar(255) DEFAULT NULL COMMENT 'SEO 关键词',
  `descript` varchar(255) DEFAULT NULL COMMENT 'SEO 描述',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COMMENT='商品分类表';

-- Create syntax for TABLE '{pre}store_product_model'
CREATE TABLE `{pre}store_product_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '产品模型表 ID',
  `api_id` bigint(20) DEFAULT NULL COMMENT '总店ID',
  `name` varchar(50) NOT NULL COMMENT '模型名称',
  `params` text COMMENT '格式内容 JSON',
  `status` tinyint(4) DEFAULT '2' COMMENT '1 禁用 2 启用',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) unsigned DEFAULT NULL COMMENT '创建人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='商品模型表';

-- Create syntax for TABLE '{pre}sys_config'
CREATE TABLE `{pre}sys_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sort` bigint(20) DEFAULT '0',
  `ele` varchar(100) DEFAULT 'input' COMMENT '标签类型 input radio select',
  `label` varchar(100) DEFAULT NULL COMMENT '标签',
  `required` tinyint(11) DEFAULT '0' COMMENT '是否为必填项',
  `pattern` varchar(100) DEFAULT NULL COMMENT '内容规则',
  `title` varchar(100) DEFAULT NULL COMMENT '内容规则失败后提示',
  `desc` text COMMENT '帮助提示',
  `option` varchar(200) DEFAULT NULL COMMENT '额外值 描述名:值#描述名2:值2',
  `type` varchar(20) DEFAULT NULL COMMENT '类型',
  `code` varchar(100) DEFAULT NULL COMMENT '编码',
  `value` varchar(500) DEFAULT NULL COMMENT '值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- Create syntax for TABLE '{pre}sys_menu'
CREATE TABLE `{pre}sys_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父id',
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `code` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '功能代码',
  `ico` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '图标',
  `url` varchar(400) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '链接，使用U函数处理',
  `request` varchar(500) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '链接参数',
  `desc` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '描述',
  `target` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `sort` int(11) DEFAULT '0' COMMENT '菜单排序',
  `status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '状态，2为启用，1为禁用',
  `create_by` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='系统菜单表';

-- Create syntax for TABLE '{pre}sys_role'
CREATE TABLE `{pre}sys_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL COMMENT '后台组名',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '是否激活 2是 ,1否',
  `group` varchar(64) DEFAULT NULL COMMENT '角色类型',
  `sort` smallint(6) unsigned DEFAULT '0' COMMENT '排序权重',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `create_by` bigint(11) DEFAULT '0' COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='系统角色表';

-- Create syntax for TABLE '{pre}sys_role_node'
CREATE TABLE `{pre}sys_role_node` (
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `node` varchar(200) DEFAULT NULL COMMENT '节点路径'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色授权关系表';

-- Create syntax for TABLE '{pre}sys_user'
CREATE TABLE `{pre}sys_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '用户登录名',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '用户登录密码',
  `role` smallint(6) unsigned DEFAULT '0' COMMENT '角色ID',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '2' COMMENT '状态 2:启用 1:禁止',
  `qq` varchar(16) DEFAULT NULL COMMENT '联系QQ',
  `mail` varchar(32) DEFAULT NULL COMMENT '联系邮箱',
  `phone` varchar(16) DEFAULT NULL COMMENT '联系手机号',
  `pid` int(11) DEFAULT NULL COMMENT '上级所属',
  `wechat` varchar(32) DEFAULT NULL COMMENT '微信号',
  `remark` varchar(255) DEFAULT '' COMMENT '备注说明',
  `login_num` int(11) DEFAULT '0' COMMENT '登录次数',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `login_ip` varchar(15) DEFAULT NULL COMMENT '最后登录IP',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `username` (`username`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='系统用户表';

-- Create syntax for TABLE '{pre}wechat_config'
CREATE TABLE `{pre}wechat_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL COMMENT '微信标识名称',
  `img` varchar(100) DEFAULT NULL COMMENT '应用图片',
  `qrc_img` varchar(100) DEFAULT NULL COMMENT '二维码',
  `username` varchar(100) DEFAULT NULL COMMENT '平台用户名',
  `password` varchar(100) DEFAULT NULL COMMENT '平台密码',
  `token` varchar(100) DEFAULT NULL COMMENT '接口token',
  `openid` varchar(100) DEFAULT NULL COMMENT '原始id',
  `wechatid` varchar(100) DEFAULT NULL COMMENT '微信号',
  `appverify` varchar(20) DEFAULT NULL COMMENT '认证情况',
  `apptype` varchar(20) DEFAULT NULL COMMENT '应用的类型',
  `appid` varchar(100) DEFAULT NULL COMMENT '高级调用功能的app id',
  `encodingaeskey` varchar(100) DEFAULT NULL COMMENT '加密用的encodingaeskey',
  `encryptmode` tinyint(4) DEFAULT '0' COMMENT '消息加解密方式 ，0、明文模式 1、兼容模式 2、安全模式',
  `appsecret` varchar(100) DEFAULT NULL COMMENT '高级调用功能的密钥',
  `partnerid` varchar(100) DEFAULT NULL COMMENT '商户身份标识',
  `partnerkey` varchar(100) DEFAULT NULL COMMENT '商户权限密钥',
  `reply` varchar(300) DEFAULT NULL COMMENT '初始回复消息',
  `status` tinyint(4) DEFAULT '2' COMMENT '状态 2启用 1禁用',
  `create_by` bigint(11) DEFAULT '0' COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10005 DEFAULT CHARSET=utf8 COMMENT='微信配置表';

-- Create syntax for TABLE '{pre}wechat_keys'
CREATE TABLE `{pre}wechat_keys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `table` varchar(20) DEFAULT NULL COMMENT '数据表名',
  `table_field` varchar(20) DEFAULT NULL COMMENT '数据表字段名',
  `table_field_value` varchar(20) DEFAULT NULL COMMENT '数据表字段值',
  `keys` varchar(200) DEFAULT NULL COMMENT '关键字，使用#,#分割',
  `type` varchar(20) DEFAULT NULL COMMENT '消息类型',
  `title` varchar(100) DEFAULT NULL COMMENT '内容的标题',
  `content` varchar(500) DEFAULT NULL COMMENT '简短的内容描述',
  `link` varchar(200) DEFAULT NULL COMMENT '链接地址',
  `url` varchar(200) DEFAULT NULL COMMENT '跳转链接',
  `qrc` varchar(500) DEFAULT NULL COMMENT '二维码地址',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10009 DEFAULT CHARSET=utf8 COMMENT='微信关键字表';

-- Create syntax for TABLE '{pre}wechat_member'
CREATE TABLE `{pre}wechat_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL COMMENT '用户分组id',
  `openid` varchar(100) DEFAULT NULL COMMENT '微信openid',
  `nickname` varchar(20) DEFAULT NULL COMMENT '微信妮称',
  `sex` varchar(2) DEFAULT '保密' COMMENT '用户性别',
  `headimgurl` varchar(500) DEFAULT NULL COMMENT '头像',
  `status` tinyint(1) DEFAULT '2' COMMENT '用户状态 2已关注 1已取消关注',
  `country` varchar(20) DEFAULT NULL COMMENT '国家',
  `province` varchar(20) DEFAULT NULL COMMENT '省份',
  `city` varchar(20) DEFAULT NULL COMMENT '城市',
  `language` varchar(30) DEFAULT NULL COMMENT '微信端语言',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `expires_in` bigint(20) DEFAULT NULL COMMENT 'Token有限时间',
  `access_token` varchar(200) DEFAULT NULL COMMENT '访问Token',
  `refresh_token` varchar(200) DEFAULT NULL COMMENT '刷新Token',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `wechat_member_openid_index` (`openid`),
  KEY `wechat_member_group_id_index` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='微信会员表';

-- Create syntax for TABLE '{pre}wechat_member_group'
CREATE TABLE `{pre}wechat_member_group` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL COMMENT '分组名',
  `description` varchar(100) DEFAULT NULL COMMENT '分组描述',
  `count` bigint(32) DEFAULT NULL,
  `sort` int(4) DEFAULT NULL COMMENT '排序',
  `status` int(2) DEFAULT '2' COMMENT '1 禁用 2 启用',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信分员分组表';

-- Create syntax for TABLE '{pre}wechat_menu'
CREATE TABLE `{pre}wechat_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) DEFAULT '0' COMMENT '父级id',
  `type` varchar(20) DEFAULT NULL COMMENT '菜单类型 null主菜单 link链接 keys关键字',
  `name` varchar(100) DEFAULT NULL COMMENT '菜单名称',
  `keys` varchar(100) DEFAULT NULL COMMENT '关键字',
  `content` varchar(500) DEFAULT NULL COMMENT '文字内容',
  `scan` varchar(100) DEFAULT NULL COMMENT '扫码',
  `pic` varchar(100) DEFAULT NULL COMMENT '发图',
  `location` varchar(100) DEFAULT NULL COMMENT '位置',
  `url` varchar(200) DEFAULT NULL COMMENT '链接地址',
  `link` varchar(200) DEFAULT NULL COMMENT '图片链接',
  `sort` bigint(20) DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='微信菜单表';

-- Create syntax for TABLE '{pre}wechat_msg'
CREATE TABLE `{pre}wechat_msg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `msgid` varchar(50) DEFAULT NULL COMMENT '消息id',
  `msgtype` varchar(20) DEFAULT NULL COMMENT '消息类型',
  `event` varchar(20) DEFAULT NULL COMMENT '事件',
  `fromusername` varchar(100) DEFAULT NULL COMMENT '发送消息的openid',
  `tousername` varchar(100) DEFAULT NULL COMMENT '接收消息的openid',
  `content` text COMMENT '消息内容',
  `eventkey` varchar(200) DEFAULT NULL COMMENT '事情key',
  `picurl` varchar(200) DEFAULT NULL COMMENT '图片链接地址',
  `mediaid` varchar(200) DEFAULT NULL COMMENT '媒体id',
  `scantype` varchar(100) DEFAULT NULL COMMENT '扫描类型',
  `scanresult` varchar(1024) DEFAULT NULL COMMENT '扫描结果',
  `sendlocationinfo` varchar(1024) DEFAULT NULL COMMENT '发送的地址信息',
  `label` varchar(255) DEFAULT NULL COMMENT '发送的地理位置字符串信息',
  `poiname` varchar(255) DEFAULT NULL COMMENT '朋友圈poi的名字，可能为空',
  `location_x` decimal(10,6) DEFAULT NULL COMMENT '主动发送位置-x',
  `location_y` decimal(10,6) DEFAULT NULL COMMENT '主动发送位置-y',
  `scale` int(11) DEFAULT NULL COMMENT '主动发送位置-规模',
  `latitude` decimal(10,6) DEFAULT NULL COMMENT '自动推送位置-纬度',
  `longitude` decimal(10,6) DEFAULT NULL COMMENT '自动推送位置-经度',
  `precision` decimal(10,6) DEFAULT NULL COMMENT '自动推送位置-精度',
  `receivedtime` bigint(20) DEFAULT NULL COMMENT '消息成功接收时间',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '消息创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2822 DEFAULT CHARSET=utf8 COMMENT='微信消息记录';

-- Create syntax for TABLE '{pre}wechat_news'
CREATE TABLE `{pre}wechat_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(30) DEFAULT NULL COMMENT '素材类型',
  `media_id` varchar(50) DEFAULT NULL COMMENT '媒体ID',
  `content` blob COMMENT '消息内容',
  `update_time` bigint(20) DEFAULT '0' COMMENT '更新时间',
  `local_update_time` bigint(20) DEFAULT NULL COMMENT '本地修改时间',
  `name` varchar(100) DEFAULT NULL COMMENT '文件名',
  `is_delete` tinyint(1) DEFAULT '0' COMMENT '0未删除，1已删除',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `update_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='微信素材表';


INSERT INTO `{pre}sys_config` (`id`, `sort`, `ele`, `label`, `required`, `pattern`, `title`, `desc`, `option`, `type`, `code`, `value`)
VALUES
	(20, 110, 'input', '网站名称', 1, NULL, '网站名称不能为空', NULL, NULL, '网站配置', 'site_name', '元培微信管理'),
	(21, 120, 'input', '网站域名', 1, NULL, '网站域名不能为空', NULL, NULL, '网站配置', 'site_domain', 'yuanpeishop.wx.cuci.cc'),
	(22, 130, 'input', 'SEO关键字', 0, NULL, NULL, NULL, NULL, '网站配置', 'site_keywords', ''),
	(23, 140, 'input', 'SEO描述', 0, NULL, NULL, NULL, NULL, '网站配置', 'site_desc', ''),
	(24, 150, 'input', '联系人', 0, NULL, NULL, NULL, NULL, '网站配置', 'site_contact', ''),
	(25, 160, 'input', '联系邮箱', 0, 'email', '请填写正确的邮箱地址', '', NULL, '网站配置', 'site_mail', ''),
	(26, 170, 'input', '联系QQ', 0, 'qq', 'QQ号码必须为不少于5位的数字', NULL, NULL, '网站配置', 'site_qq', ''),
	(19, 125, 'input', '公司名称', 1, NULL, '请输入公司名称', NULL, NULL, '网站配置', 'site_company', '广州楚才信息科技有限公司'),
	(83, 190, 'input', '程序名称', 1, NULL, '程序名不能为空', NULL, NULL, '程序信息', 'app_name', '元培微信管理'),
	(84, 200, 'input', '程序版本', 1, NULL, '程序版本号不能为空', NULL, NULL, '程序信息', 'app_version', '1.0 beta'),
	(85, 210, 'input', '程序Logo', 1, NULL, '程序LOGO样式不能为空', NULL, NULL, '程序信息', 'app_logo', 'glyphicon glyphicon-apple'),
	(86, 220, 'input', 'Bucket', 0, NULL, NULL, NULL, NULL, '七牛云存储', 'qiniu_bucket', 'ueditor'),
	(87, 230, 'input', 'AccessKey', 0, NULL, NULL, NULL, NULL, '七牛云存储', 'qiniu_accesskey', 'kptWm2wG3vcc5vdG-_H5PTeafNojw8uPV86FHuH5'),
	(88, 240, 'input', 'SecretKey', 0, NULL, NULL, '如果还没有帐号，请点击<a target=\"_blank\" href=\"https://portal.qiniu.com/signup?code=3lhz6nmnwbple\">免费申请10G存储空间</a>，申请成功后添加Bucket，并设置为公开空间！', NULL, '七牛云存储', 'qiniu_secretkey', 'LmCAwO_xBzfz0rlEujPZn3eI8v3f9_UNFeroj3wG'),
	(89, 225, 'input', 'Domain', 0, NULL, NULL, '只需填写域名，如：static.wxphp.cn', NULL, '七牛云存储', 'qiniu_domain', 'ueditor.cdn.cuci.cc'),
	(100, 270, 'input', 'SMTP服务器', 0, NULL, NULL, NULL, NULL, '邮件服务配置', 'mail_smtp', 'smtp.qq.com'),
	(105, 290, 'input', 'SMTP帐号', 0, NULL, NULL, NULL, NULL, '邮件服务配置', 'mail_username', 'pm@cuci.cc'),
	(104, 280, 'input', 'SMTP端口号', 0, NULL, NULL, NULL, NULL, '邮件服务配置', 'mail_port', '465'),
	(106, 300, 'input', 'SMTP密码', 0, NULL, NULL, NULL, NULL, '邮件服务配置', 'mail_password', 'Test12345'),
	(107, 285, 'radio', '是否需要验证', 0, NULL, NULL, NULL, '不需要:0,需要:1', '邮件服务配置', 'mail_smtp_auth', '1'),
	(108, 265, 'input', '发信邮箱', 0, 'email', '请输入正确的邮箱地址', '通常设置与SMTP帐号一致', NULL, '邮件服务配置', 'mail_from', 'pm@cuci.cc'),
	(109, 255, 'input', '发信人', 0, NULL, NULL, '', NULL, '邮件服务配置', 'mail_from_name', '楚才API管理中心'),
	(111, 310, 'radio', '是否加密', 0, NULL, NULL, NULL, '不加密:,ssl:ssl,tls:tls', '邮件服务配置', 'mail_secure', 'ssl'),
	(112, 268, 'input', '回复收信邮箱', 0, 'email', '请输入正确的邮箱地址', NULL, NULL, '邮件服务配置', 'mail_reply', 'zoujingli@qq.com'),
	(113, 215, 'input', '百度统计KEY', 0, NULL, '', NULL, NULL, '程序信息', 'app_baidu_tongji_key', 'df31b90409cbd7237728ca1a770d72e6');


INSERT INTO `{pre}sys_menu` (`id`, `pid`, `title`, `code`, `ico`, `url`, `request`, `desc`, `target`, `sort`, `status`, `create_by`, `create_date`, `update_by`, `update_date`)
VALUES
	(1, 0, '系统管理', '', '', '#', '', '', '_self', 9000, 2, 1, '2015-04-13 10:09:05', 1, '2015-04-22 11:00:07'),
	(2, 1, '菜单管理', 'Admin/Menu/index', '', 'Admin/Menu/index', '', '', '_self', 100, 2, 1, '2015-04-13 10:09:30', 1, '2015-04-22 11:00:07'),
	(3, 1, '角色管理', 'Admin/Role/index', '', 'Admin/Role/index', '', '', '_self', 200, 2, 1, '2015-04-13 10:10:05', 1, '2015-04-22 11:00:08'),
	(4, 1, '系统配置', 'Admin/Config/index', '', 'Admin/Config/index', '', '', '_self', 300, 2, 1, '2015-04-13 10:10:33', 1, '2015-04-22 11:00:08'),
	(5, 1, '用户管理', 'Admin/User/index', '', 'Admin/User/index', '', '', '_self', 400, 2, 1, '2015-04-13 10:11:01', 1, '2015-04-22 11:00:08'),
	(6, 0, '用户中心', '', '', '#', '', '', '_self', 7000, 1, 1, '2015-04-13 10:39:21', 1, '2015-04-22 11:00:06'),
	(7, 6, '应用管理(不能动)', 'User/App/index', '', 'User/App/index', '', '', '_self', 100, 1, 1, '2015-04-13 10:41:29', 1, '2015-04-22 11:00:06'),
	(8, 0, '公众号管理', '', '', '#', '', '', '_self', 8000, 2, 1, '2015-04-14 12:51:30', 1, '2015-04-22 11:00:06'),
	(9, 8, '公众号配置', 'Wechat/Config/index', '', 'Wechat/Config/index', '', '', '_self', 100, 2, 1, '2015-04-14 12:51:55', 1, '2015-04-22 11:00:07'),
	(10, 8, '关键字管理', 'Wechat/Keys/index', '', 'Wechat/Keys/index', '', '', '_self', 200, 2, 1, '2015-04-14 12:52:50', 1, '2015-04-22 11:00:07'),
	(11, 8, '微信菜单', 'Wechat/Menu/index', '', 'Wechat/Menu/index', '', '', '_self', 300, 2, 1, '2015-04-14 12:53:19', 1, '2015-04-27 18:28:47'),
	(12, 8, '微信素材', 'Wechat/News/index', '', 'Wechat/News/index', '', '', '_self', 400, 2, 1, '2015-04-14 20:26:44', 1, '2015-04-27 18:28:55'),
	(14, 8, '会员管理', 'Wechat/Member/index', '', 'Wechat/Member/index', '', '', '_self', 600, 2, 1, '2015-04-17 16:00:48', 1, '2015-04-27 18:29:10'),
	(15, 0, '微商城', '', '', '#', '', '', '_self', 5000, 2, 1, '2015-04-21 10:28:31', 1, '2015-04-27 15:38:30'),
	(16, 15, '商城配置', 'Store/Config/index', '', 'Store/Config/index', '', '', '_self', 100, 2, 1, '2015-04-21 10:28:57', 1, '2015-04-22 11:00:05'),
	(17, 50, '商品规格', 'Store/ProductModel/index', '', 'Store/ProductModel/index', '', '', '_self', 10, 2, 1, '2015-04-21 10:29:19', 1, '2015-04-28 21:40:57'),
	(18, 15, '订单管理', 'Store/Order/index', '', 'Store/Order/index', '', '', '_self', 400, 2, 1, '2015-04-21 10:29:42', 1, '2015-04-22 11:00:05'),
	(19, 50, '商品管理', 'Store/Product/index', '', 'Store/Product/index', '', '', '_self', 20, 2, 1, '2015-04-21 10:30:04', 1, '2015-04-28 21:40:41'),
	(20, 50, '商品分类', 'Store/ProductCat/index', '', 'Store/ProductCat/index', '', '', '_self', 30, 2, 1, '2015-04-21 10:30:27', 1, '2015-04-28 21:40:24'),
	(21, 15, '快递管理', 'Store/Delivery/index', '', 'Store/Delivery/index', '', '', '_self', 500, 2, 1, '2015-04-21 10:31:01', 1, '2015-04-22 11:00:05'),
	(24, 0, '微官网', '', '', '#', '', '', '_self', 6000, 2, 1, '2015-04-21 17:38:36', 1, '2015-04-27 15:38:48'),
	(23, 15, '积分兑换', 'Store/Credit/index', '', 'Store/Credit/index', '', '', '_self', 600, 2, 1, '2015-04-21 10:31:57', 1, '2015-04-22 11:00:06'),
	(25, 24, '内容管理', '', '', '#', '', '', '_self', 100, 2, 1, '2015-04-21 17:41:00', 1, '2015-04-28 11:33:03'),
	(26, 25, '内容列表', 'Site/Content/index', '', 'Site/Content/index', '', '', '_self', 10, 2, 1, '2015-04-21 17:41:21', 1, '2015-04-22 17:32:52'),
	(27, 25, '分类管理', 'Site/Cat/index', '', 'Site/Cat/index', '', '', '_self', 20, 2, 1, '2015-04-21 17:42:02', 1, '2015-04-22 17:31:02'),
	(32, 24, '微官网管理', '', '', '#', '', '', '_self', 0, 2, 1, '2015-04-23 09:07:47', 1, '2015-04-28 21:38:59'),
	(29, 0, '营销活动', '', '', '#', '', '', '_self', 4000, 2, 1, '2015-04-22 10:59:56', 1, '2015-05-06 16:48:13'),
	(30, 1, '分享有礼', 'Apps/Share/index', '', 'Apps/Share/index', '', '', '_self', 100, 1, 1, '2015-04-22 11:00:55', 1, '2015-05-06 16:50:19'),
	(31, 29, '照片评比', '', '', '#', '', '', '_self', 200, 2, 1, '2015-04-22 11:01:29', 1, '2015-05-09 14:30:47'),
	(33, 32, '网站开关', 'Site/Config/index', '', 'Site/Config/index', '', '', '_self', 0, 2, 1, '2015-04-23 09:55:07', 1, '2015-04-24 13:40:21'),
	(34, 32, '页面管理', 'Site/Page/index', '', 'Site/Page/index', '', '', '_self', 0, 2, 1, '2015-04-23 09:56:57', 1, '2015-04-24 13:40:29'),
	(35, 29, '宝宝日记', 'Apps/Daily/index', '', 'Apps/Daily/index', '', '', '_self', 300, 2, 1, '2015-04-23 10:37:08', 1, '2015-04-23 10:44:37'),
	(36, 29, '拼图游戏管理', '', '', '#', '', '', '_self', 400, 2, 1, '2015-04-23 10:50:03', 1, '2015-04-23 10:58:25'),
	(37, 36, '拼图游戏配置', 'Apps/Puzzle/edit', '', 'Apps/Puzzle/edit', '', '', '_self', 10, 2, 1, '2015-04-23 10:50:27', 1, '2015-04-23 17:37:01'),
	(38, 36, '游戏记录', 'Apps/Puzzle/index', '', 'Apps/Puzzle/index', '', '', '_self', 20, 2, 1, '2015-04-23 10:51:17', 1, '2015-04-23 10:58:47'),
	(42, 29, '砸金蛋管理', '', '', '#', '', '', '_self', 700, 2, 1, '2015-04-23 17:09:16', 1, '2015-04-23 17:16:46'),
	(40, 29, '有奖问答', 'Apps/Survey/index', '', 'Apps/Survey/index', '', '', '_self', 500, 2, 1, '2015-04-23 10:54:30', 1, '2015-04-23 11:01:59'),
	(49, 32, '模块管理', 'Site/Module/index', '', 'Site/Module/index', '', '', '_self', 0, 2, 1, '2015-04-24 11:22:51', 1, '2015-04-24 13:40:39'),
	(43, 42, '砸金蛋配置', 'Apps/Eggs/index', '', 'Apps/Eggs/index', '', '', '_self', 10, 2, 1, '2015-04-23 17:09:36', 1, '2015-04-23 17:17:07'),
	(44, 42, '中奖纪录', 'Apps/Eggs/record', '', 'Apps/Eggs/record', '', '', '_self', 20, 2, 1, '2015-04-23 17:10:03', 1, '2015-04-23 17:17:33'),
	(45, 29, '大转盘管理', '', '', '#', '', '', '_self', 800, 2, 1, '2015-04-23 17:12:06', 1, '2015-04-23 17:19:36'),
	(46, 45, '配置信息', 'Apps/Lottery/index', '', 'Apps/Lottery/index', '', '', '_self', 10, 2, 1, '2015-04-23 17:12:26', 1, '2015-04-23 17:19:57'),
	(47, 45, '中奖纪录', 'Apps/Lottery/record', '', 'Apps/Lottery/record', '', '', '_self', 20, 2, 1, '2015-04-23 17:12:48', 1, '2015-04-23 17:20:18'),
	(55, 31, '照片评比活动', 'Apps/CompareList/index', '', 'Apps/CompareList/index', '', '', '_self', 10, 2, 1, '2015-05-09 14:32:47', 1, '2015-05-09 14:32:41'),
	(50, 15, '商品管理', '', '', '#', '', '', '_self', 200, 2, 1, '2015-04-28 21:39:16', 1, '2015-04-28 21:40:05'),
	(51, 15, '积分商城管理', '', '', '#', '', '', '_self', 300, 2, 1, '2015-05-05 11:09:28', 1, '2015-05-05 11:11:20'),
	(52, 51, '积分订单', 'Store/Credit/index', '', 'Store/Credit/index', '', '', '_self', 20, 2, 1, '2015-05-05 11:12:12', 1, '2015-05-05 11:12:10'),
	(53, 51, '积分商品管理', 'Store/CreditProduct/index', '', 'Store/CreditProduct/index', '', '', '_self', 10, 2, 1, '2015-05-05 11:26:46', 1, '2015-05-05 11:26:59'),
	(56, 31, '照片评比记录', 'Apps/Compare/index', '', 'Apps/Compare/index', '', '', '_self', 20, 2, 1, '2015-05-09 14:33:40', 1, '2015-05-09 14:33:34');
