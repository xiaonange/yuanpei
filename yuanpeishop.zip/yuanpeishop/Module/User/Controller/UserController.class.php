<?php

namespace User\Controller;

use Admin\Controller\AdminController;

class UserController extends AdminController {

    public $gtitle = '用户中心';

}
