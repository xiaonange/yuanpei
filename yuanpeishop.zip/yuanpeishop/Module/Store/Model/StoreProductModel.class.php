<?php

namespace Store\Model;

/**
 * 产品管理模型
 * 
 * @author zoujingli <zoujingli@qq.com>
 * @date 2014/09/04 14:55:02
 */
class StoreProductModel extends StoreModel {
    
}
