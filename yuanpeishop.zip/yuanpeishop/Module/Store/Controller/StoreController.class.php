<?php

namespace Store\Controller;

use Wechat\Controller\WechatController;

/**
 * 店铺基础控制器类
 * 
 * @author zoujingli <zoujingli@qq.com>
 * @date 2014/09/04 13:59:00
 */
class StoreController extends WechatController {

    public $gtitle = '商城管理';

}
