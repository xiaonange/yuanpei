<?php

return array(
    'URL_HTML_SUFFIX' => 'js',
);
