<?php

namespace Apps\Controller;

use Wechat\Controller\WechatController;

/**
 * 营销活动管理
 */
class AppsController extends WechatController {

    /**
     * 设置模块标题
     * @var type 
     */
    public $gtitle = '营销活动';

}
