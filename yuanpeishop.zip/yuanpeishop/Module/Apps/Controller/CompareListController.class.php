<?php

/* * * * * * * * * * * * * * * * * * * * * *
 * * * * OH, NO BUG NO BUG, OH YEAH! * * * *
 * * * * * * * * * * * * * * * * * * * * * *
 */

namespace Apps\Controller;

/**
 * Description of ComparecatController
 *
 * @author luoshaobo <shao156324@sina.com>
 * @date 2015-5-9 13:54:18
 */
class CompareListController extends AppsController {

    /**
     * 定义模型名称
     * @var type 
     */
    public $ptitle = '照片评比活动列表';

    /**
     * 设定可访问的操作
     * @var type 
     */
    public $access = array(
        'index'  => '评比列表',
        'add'    => '添加选项',
        'edit'   => '修改选项',
        'del'    => '删除选项',
        'resume' => '启用',
        'forbid' => '禁用',
    );

    /**
     * 设定可设置为菜单的节点
     * @var type 
     */
    public $menu = array(
        'index' => '评比活动列表'
    );

    /**
     * 绑定操作模型
     * @var type 
     */
    protected $_bind_model = 'AppsVote';

    protected function _filter(&$model, &$map) {
        ($kw = I('get._kw')) && $map['title'] = array('like', "%$kw%");
    }

    /**
     * 编辑成功后的处理
     * @param type $model
     * @param type $data
     */
    protected function _form_success(&$model, $data) {
        if (IS_POST) {
            $id = $data['id'];
            if (!empty($id) && intval($data['status']) === 2) {
                $this->_setSelfActive(array($id));
            }
        }
    }

    /**
     * 启用的回调方法
     * @param type $model
     * @param type $data
     */
    protected function _resume_success(&$model, $data) {
        if (IS_POST) {
            $ids = $data['ids'];
            if (!empty($ids)) {
                $this->_setSelfActive($ids);
            }
        }
    }

    /**
     * 设置当前活动
     * @param type $ids
     * @return type
     */
    private function _setSelfActive($ids) {
        return M($this->_bind_model)->where(array('id' => array('not in', $ids)))->setField('status', '1');
    }

}
