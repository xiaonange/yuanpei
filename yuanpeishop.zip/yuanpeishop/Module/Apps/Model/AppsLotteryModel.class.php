<?php

namespace Apps\Model;

class AppsLotteryModel extends AppsModel {
    
}
