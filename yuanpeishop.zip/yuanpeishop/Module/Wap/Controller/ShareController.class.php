<?php

namespace Wap\Controller; // 导入分页类

/**
 * 分享有礼控制器
 * @author luoshaobo <shao156324@sina.com>
 * @time 2015-05-18 18:00
 */

class ShareController extends WapController {

    public $ptitle = "分享有礼";

    /**
     * 用户信息检测
     */
    public function _initialize() {
        parent::_initialize();
        $this->getMember($this->oauth(), null, false);
    }

    /**
     * 绑定操作的模型
     * @var type 
     */
    protected $_bind_model = 'SiteContent';

    /**
     * 首页列表
     */
    public function _index_list_filter(&$model, &$map) {
        $map = array("status" => 2);
        $map['integral'] = array("gt", 0);

        /* 获取商城信息 */
        $info = M("Store")->find(1);
        $info['link'] = explode('|', "{$info['link']}");
        if (!empty($info['url'])) {
            redirect($info['url']);
        }
        $this->assign('store', $info);
    }

}
