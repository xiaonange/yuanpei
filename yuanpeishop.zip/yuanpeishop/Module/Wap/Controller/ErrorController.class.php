<?php

namespace Wap\Controller;

use Think\Controller;

/**
 * 模块默认控制器
 */
class ErrorController extends Controller {

    /**
     * 显示错误页面
     */
    public function show($title = '抱歉', $info = '您要访问的内容被怪兽<br />吃掉了') {
        $msg = array();
        $msg['status'] = 0;
        $msg['ptitle'] = '系统提示';
        $msg['title'] = I('get.title', $title, 'trim');
        $msg['info'] = I('get.info', $info, 'trim');
        $this->assign($msg);
        $this->display(T('Wap@Empty:error'));
        die();
    }

    /**
     * 引入用户关注
     */
    public function wechat() {
        $this->assign('config', M('WechatConfig')->find(1));
        $this->assign('ptitle', '关注');
        $this->display(T('Wap@Empty:wechat'));
        die();
    }

}
