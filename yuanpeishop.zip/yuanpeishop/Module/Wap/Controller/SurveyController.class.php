<?php

namespace Wap\Controller;

class SurveyController extends WapController {

    /**
     * 用户信息检测
     */
    public function _initialize() {
        parent::_initialize();
        $this->getMember($this->oauth(), null, false);
    }

    /**
     * 微调研问答首页
     */
    public function index() {
        $info = M('AppsSurvey')->find(I('id', 1, 'intval'));
        if ($info['status'] != 2) {
            $this->assign('notimsg', $info['content']);
            $this->display('result');
            exit();
        }
        $count = M('AppsSurveyRecord')->where(array('openid' => $this->openid))->count();
        if ($count >= $info['count']) {
            $this->assign('notimsg', '您已经参加过了。每人只能参加' . $info['count'] . '次哦~~');
            $this->display('result');
            exit();
        }
        $list = M('AppsSurveyProblem')->where(array('status' => 2))->order('id ASC')->select();
        $this->assign('list', $list);
        $this->assign('info', $info);
        $this->assign('ptitle', "有奖问答活动");
        $this->display();
    }

    /**
     * 微调研问答提交
     */
    public function submit() {
        $openid = $this->openid;
        $info = M('AppsSurvey')->find(I('id', 1, 'intval'));

        $count = M('AppsSurveyRecord')->where(array('openid' => $openid))->count();
        if ($count >= $info['count']) {
            $this->assign('notimsg', '您已经参加过了。每人只能参加' . $info['count'] . '次哦~~');
            $this->display('result');
            die();
        }
        $answer = $_POST;

        foreach ($answer as $key => $value) {
            foreach ($value as $k => $v) {
                M('AppsSurveyProblem')->where(array('id' => $key))->setInc('number_' . $v);
            }
        }

        $data['name'] = I('post.name');
        $data['tel'] = I('post.tel');
        $data['integral'] = $info['integral'];
        $data['openid'] = $openid;
        M('AppsSurveyRecord')->add($data);
        D('Shop/MemberIntegral')->changeIntegral($this->openid, $info['integral'], '答题有奖');
        $this->assign('notimsg', '提交成功，感谢您参加本次问卷调查~~');
        $this->assign('ptitle', "操作提示");
        $this->display('result');
    }

}
