<?php

namespace Site\Model;

class SiteModuleModel extends SiteContentModel {

}
